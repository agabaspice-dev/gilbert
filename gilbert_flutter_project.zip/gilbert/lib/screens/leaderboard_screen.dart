import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_colors.dart';
import '../providers/player_provider.dart';

/// Leaderboard UI wired to local mock data. In production, swap
/// `_mockEntries()` for a real backend call (Firebase, Supabase, custom
/// API, or Game Center / Play Games Services leaderboards) — the widget
/// tree and model shape below are already structured for that.
class LeaderboardEntry {
  final String name;
  final int stars;
  final bool isPlayer;
  const LeaderboardEntry(this.name, this.stars, {this.isPlayer = false});
}

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  List<LeaderboardEntry> _mockEntries(int playerStars) {
    final entries = [
      const LeaderboardEntry('Ava', 412),
      const LeaderboardEntry('Noah', 388),
      const LeaderboardEntry('Mia', 356),
      const LeaderboardEntry('Leo', 301),
      const LeaderboardEntry('Zoe', 275),
      LeaderboardEntry('You', playerStars, isPlayer: true),
      const LeaderboardEntry('Kai', 190),
      const LeaderboardEntry('Ivy', 154),
    ];
    entries.sort((a, b) => b.stars.compareTo(a.stars));
    return entries;
  }

  @override
  Widget build(BuildContext context) {
    final profile = context.watch<PlayerProvider>().profile;
    final entries = _mockEntries(profile.totalStars);

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Column(
            children: [
              AppBar(
                title: const Text('Leaderboard'),
                backgroundColor: Colors.transparent,
                bottom: TabBar(
                  controller: _tabController,
                  indicatorColor: AppColors.gilbertGold,
                  labelColor: AppColors.gilbertGold,
                  unselectedLabelColor: AppColors.textSecondary,
                  tabs: const [Tab(text: 'Global'), Tab(text: 'Friends')],
                ),
              ),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildList(entries),
                    _buildList(entries.take(4).toList()),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildList(List<LeaderboardEntry> entries) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: entries.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final e = entries[i];
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: e.isPlayer ? AppColors.gilbertGold.withOpacity(0.15) : AppColors.indigoMid,
            borderRadius: BorderRadius.circular(14),
            border: e.isPlayer
                ? Border.all(color: AppColors.gilbertGold)
                : null,
          ),
          child: Row(
            children: [
              SizedBox(
                width: 28,
                child: Text('${i + 1}',
                    style: TextStyle(
                        color: i < 3 ? AppColors.gilbertGold : AppColors.textSecondary,
                        fontWeight: FontWeight.w800)),
              ),
              const CircleAvatar(
                radius: 16,
                backgroundColor: AppColors.indigoNight,
                child: Icon(Icons.person, size: 18, color: AppColors.textSecondary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(e.name,
                    style: const TextStyle(
                        color: AppColors.textPrimary, fontWeight: FontWeight.w700)),
              ),
              const Icon(Icons.star_rounded, color: AppColors.gilbertGold, size: 18),
              const SizedBox(width: 4),
              Text('${e.stars}', style: const TextStyle(color: AppColors.textPrimary)),
            ],
          ),
        );
      },
    );
  }
}
