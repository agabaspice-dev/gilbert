import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_constants.dart';
import '../core/theme/app_colors.dart';
import '../providers/player_provider.dart';
import '../widgets/coin_badge.dart';
import '../widgets/gilbert_logo.dart';
import '../widgets/hint_and_streak_widgets.dart';
import '../widgets/level_node.dart';
import 'achievements_screen.dart';
import 'daily_challenge_screen.dart';
import 'game_screen.dart';
import 'leaderboard_screen.dart';
import 'mystery_words_screen.dart';
import 'profile_screen.dart';
import 'speed_mode_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _worldScrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    final playerProvider = context.watch<PlayerProvider>();
    final profile = playerProvider.profile;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Column(
            children: [
              _buildTopBar(context, profile),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: DailyStreakBanner(streak: profile.loginStreak),
              ),
              const SizedBox(height: 16),
              _buildModeRow(context),
              const SizedBox(height: 16),
              Expanded(child: _buildWorldMap(context, profile)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context, profile) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          const GilbertLogo(size: 44),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              AppConstants.appName,
              style: Theme.of(context)
                  .textTheme
                  .headlineMedium
                  ?.copyWith(fontSize: 22),
            ),
          ),
          IconButton(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const ProfileScreen())),
            icon: const Icon(Icons.person_rounded, color: AppColors.textPrimary),
          ),
          CoinBadge(
            coins: profile.coins,
            onTap: () {}, // TODO: open IAP coin shop
          ),
        ],
      ),
    );
  }

  Widget _buildModeRow(BuildContext context) {
    final modes = [
      _ModeCardData('Daily\nChallenge', Icons.calendar_today_rounded,
          AppColors.streakCoral, () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const DailyChallengeScreen()))),
      _ModeCardData('Speed\nMode', Icons.timer_rounded, AppColors.error,
          () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const SpeedModeScreen()))),
      _ModeCardData('Mystery\nWords', Icons.auto_awesome_rounded,
          AppColors.cellBonus, () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const MysteryWordsScreen()))),
      _ModeCardData('Leader-\nboard', Icons.leaderboard_rounded,
          AppColors.gilbertGold, () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const LeaderboardScreen()))),
      _ModeCardData('Achieve-\nments', Icons.military_tech_rounded,
          AppColors.success, () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const AchievementsScreen()))),
    ];

    return SizedBox(
      height: 96,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: modes.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) => _ModeCard(data: modes[i]),
      ),
    );
  }

  Widget _buildWorldMap(BuildContext context, profile) {
    return ListView.builder(
      controller: _worldScrollController,
      padding: const EdgeInsets.symmetric(vertical: 12),
      itemCount: AppConstants.worldsCount,
      itemBuilder: (context, worldPos) {
        final worldIndex = worldPos + 1;
        final isWorldUnlocked = worldIndex <= profile.currentWorldIndex;
        return _WorldSection(
          worldIndex: worldIndex,
          isUnlocked: isWorldUnlocked,
          currentWorld: profile.currentWorldIndex,
          currentLevel: profile.currentLevelIndex,
        );
      },
    );
  }
}

class _ModeCardData {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  _ModeCardData(this.label, this.icon, this.color, this.onTap);
}

class _ModeCard extends StatelessWidget {
  final _ModeCardData data;
  const _ModeCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: data.onTap,
      child: Container(
        width: 84,
        decoration: BoxDecoration(
          color: AppColors.indigoMid,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: data.color.withOpacity(0.4)),
        ),
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(data.icon, color: data.color, size: 26),
            const SizedBox(height: 6),
            Text(
              data.label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 11,
                  fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}

class _WorldSection extends StatelessWidget {
  final int worldIndex;
  final bool isUnlocked;
  final int currentWorld;
  final int currentLevel;

  const _WorldSection({
    required this.worldIndex,
    required this.isUnlocked,
    required this.currentWorld,
    required this.currentLevel,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isUnlocked ? Icons.public_rounded : Icons.lock_rounded,
                color: isUnlocked
                    ? AppColors.gilbertGold
                    : AppColors.textSecondary,
                size: 18,
              ),
              const SizedBox(width: 6),
              Text('World $worldIndex',
                  style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w800,
                      fontSize: 16)),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 84,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: AppConstants.levelsPerWorld,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (context, levelPos) {
                final levelIndex = levelPos + 1;
                final isLocked = !isUnlocked ||
                    (worldIndex == currentWorld && levelIndex > currentLevel) ||
                    (worldIndex > currentWorld);
                final isCurrent =
                    worldIndex == currentWorld && levelIndex == currentLevel;
                return LevelNode(
                  levelIndex: levelIndex,
                  isLocked: isLocked,
                  isCurrent: isCurrent,
                  stars: (!isLocked && !isCurrent) ? 3 : 0,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => GameScreen(
                        worldIndex: worldIndex,
                        levelIndex: levelIndex,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
