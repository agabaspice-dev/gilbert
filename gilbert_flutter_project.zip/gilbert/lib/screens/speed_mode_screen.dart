import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants/app_constants.dart';
import '../core/theme/app_colors.dart';
import '../data/level_generator.dart';
import '../data/word_bank.dart';
import '../models/level.dart';
import '../providers/player_provider.dart';
import '../widgets/coin_badge.dart';
import '../widgets/letter_circle.dart';

/// Speed Mode: solve as many words as possible from a rotating set of
/// letter puzzles before the clock runs out. Distinct ruleset from
/// Classic — no crossword board, pure word-finding under time pressure.
class SpeedModeScreen extends StatefulWidget {
  const SpeedModeScreen({super.key});

  @override
  State<SpeedModeScreen> createState() => _SpeedModeScreenState();
}

class _SpeedModeScreenState extends State<SpeedModeScreen> {
  int _secondsLeft = AppConstants.speedModeRoundSeconds;
  Timer? _timer;
  bool _started = false;
  bool _finished = false;
  int _score = 0;
  int _wordsFound = 0;
  late GilbertLevel _currentPuzzle;
  final Set<String> _foundInRound = {};

  @override
  void initState() {
    super.initState();
    _rollNewPuzzle();
  }

  void _rollNewPuzzle() {
    final rng = Random();
    _currentPuzzle = LevelGenerator.generateSingle(0, rng.nextInt(9000) + 1);
    _foundInRound.clear();
  }

  void _start() {
    setState(() {
      _started = true;
      _secondsLeft = AppConstants.speedModeRoundSeconds;
      _score = 0;
      _wordsFound = 0;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() => _secondsLeft--);
      if (_secondsLeft <= 0) {
        t.cancel();
        setState(() => _finished = true);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  final List<int> _selected = [];

  void _submit(PlayerProvider playerProvider) {
    final word = _selected.map((i) => _currentPuzzle.letters[i]).join();
    setState(() => _selected.clear());
    if (word.length < AppConstants.minWordLength) return;

    final validWords = {
      ...WordBank.tier1,
      ...WordBank.tier2,
      ...WordBank.tier3,
      ...WordBank.tier4
    };
    if (!validWords.contains(word) || _foundInRound.contains(word)) return;

    _foundInRound.add(word);
    final coins = AppConstants.coinsSpeedModeWordBase + word.length;
    setState(() {
      _score += coins;
      _wordsFound++;
    });
    playerProvider.addCoins(coins);

    if (_foundInRound.length >= 4) {
      setState(_rollNewPuzzle);
    }
  }

  @override
  Widget build(BuildContext context) {
    final playerProvider = context.watch<PlayerProvider>();

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.arrow_back_ios_new_rounded,
                          color: AppColors.textPrimary),
                    ),
                    const Expanded(
                      child: Text('Speed Mode',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w700)),
                    ),
                    CoinBadge(coins: playerProvider.profile.coins),
                  ],
                ),
              ),
              if (!_started) _buildIntro(context),
              if (_started && !_finished) _buildRound(context, playerProvider),
              if (_finished) _buildResults(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIntro(BuildContext context) {
    return Expanded(
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.timer_rounded, color: AppColors.error, size: 72),
            const SizedBox(height: 16),
            Text('${AppConstants.speedModeRoundSeconds} Seconds',
                style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text('Find as many words as you can before time runs out.',
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center),
            const SizedBox(height: 24),
            ElevatedButton(onPressed: _start, child: const Text('Start')),
          ],
        ),
      ),
    );
  }

  Widget _buildRound(BuildContext context, PlayerProvider playerProvider) {
    return Expanded(
      child: Column(
        children: [
          const SizedBox(height: 8),
          Text(
            '$_secondsLeft s',
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.w900,
              color: _secondsLeft <= 10
                  ? AppColors.error
                  : AppColors.gilbertGold,
            ),
          ),
          Text('$_wordsFound words · $_score coins',
              style: const TextStyle(color: AppColors.textSecondary)),
          const Spacer(),
          Text(
            _selected.map((i) => _currentPuzzle.letters[i]).join(),
            style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
                letterSpacing: 4),
          ),
          const SizedBox(height: 12),
          LetterCircle(
            letters: _currentPuzzle.letters,
            selectedIndices: _selected,
            onLetterEntered: (i) => setState(() {
              if (!_selected.contains(i)) _selected.add(i);
            }),
            onReleased: () => _submit(playerProvider),
          ),
          const Spacer(),
        ],
      ),
    );
  }

  Widget _buildResults(BuildContext context) {
    return Expanded(
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.emoji_events_rounded,
                color: AppColors.gilbertGold, size: 72),
            const SizedBox(height: 12),
            Text('Time\'s Up!', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text('$_wordsFound words · $_score coins earned',
                style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => setState(() {
                _finished = false;
                _started = false;
                _rollNewPuzzle();
              }),
              child: const Text('Play Again'),
            ),
          ],
        ),
      ),
    );
  }
}
