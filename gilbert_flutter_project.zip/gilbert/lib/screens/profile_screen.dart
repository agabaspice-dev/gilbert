import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_colors.dart';
import '../providers/player_provider.dart';
import '../widgets/gilbert_logo.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final profile = context.watch<PlayerProvider>().profile;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Column(
            children: [
              AppBar(
                title: const Text('Profile'),
                backgroundColor: Colors.transparent,
              ),
              const SizedBox(height: 8),
              const GilbertLogo(size: 88),
              const SizedBox(height: 12),
              Text(profile.displayName,
                  style: Theme.of(context).textTheme.headlineMedium),
              Text('World ${profile.currentWorldIndex} · Level ${profile.currentLevelIndex}',
                  style: const TextStyle(color: AppColors.textSecondary)),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.6,
                  children: [
                    _StatCard(
                        icon: Icons.monetization_on_rounded,
                        label: 'Coins',
                        value: '${profile.coins}',
                        color: AppColors.coin),
                    _StatCard(
                        icon: Icons.star_rounded,
                        label: 'Stars',
                        value: '${profile.totalStars}',
                        color: AppColors.gilbertGold),
                    _StatCard(
                        icon: Icons.text_fields_rounded,
                        label: 'Words Found',
                        value: '${profile.totalWordsFound}',
                        color: AppColors.success),
                    _StatCard(
                        icon: Icons.auto_awesome_rounded,
                        label: 'Bonus Words',
                        value: '${profile.totalBonusWordsFound}',
                        color: AppColors.cellBonus),
                    _StatCard(
                        icon: Icons.local_fire_department_rounded,
                        label: 'Login Streak',
                        value: '${profile.loginStreak} days',
                        color: AppColors.streakCoral),
                    _StatCard(
                        icon: Icons.military_tech_rounded,
                        label: 'Achievements',
                        value: '${profile.unlockedAchievementIds.length}',
                        color: AppColors.error),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.indigoMid,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 6),
          Text(value,
              style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w800,
                  fontSize: 18)),
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
        ],
      ),
    );
  }
}
