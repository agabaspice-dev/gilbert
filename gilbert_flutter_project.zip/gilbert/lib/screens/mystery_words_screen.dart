import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../data/level_generator.dart';
import 'game_screen.dart';

/// Mystery Words mode: a curated set of levels chosen for their richness
/// of hidden bonus words, framed as a dedicated "treasure hunt" mode.
class MysteryWordsScreen extends StatelessWidget {
  const MysteryWordsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Highlight levels with the most bonus words across a sample of worlds.
    final candidates = List.generate(20, (i) {
      final world = i + 1;
      return LevelGenerator.generateSingle(world, 3);
    })
      ..sort((a, b) => b.bonusWords.length.compareTo(a.bonusWords.length));

    final featured = candidates.take(10).toList();

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Column(
            children: [
              AppBar(
                title: const Text('Mystery Words'),
                backgroundColor: Colors.transparent,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  'These puzzles hide extra bonus words in their letters. '
                  'Find them all for maximum coins.',
                  style: Theme.of(context).textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: featured.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final level = featured[i];
                    return Container(
                      decoration: BoxDecoration(
                        color: AppColors.indigoMid,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: AppColors.cellBonus.withOpacity(0.4)),
                      ),
                      child: ListTile(
                        leading: const Icon(Icons.auto_awesome_rounded,
                            color: AppColors.cellBonus),
                        title: Text(
                          'Mystery Puzzle ${i + 1}',
                          style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w700),
                        ),
                        subtitle: Text(
                          '${level.bonusWords.length} hidden words · '
                          '${level.boardWords.length} board words',
                          style: const TextStyle(color: AppColors.textSecondary),
                        ),
                        trailing: const Icon(Icons.chevron_right_rounded,
                            color: AppColors.gilbertGold),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => GameScreen(
                              preloadedLevel: level,
                              mode: GilbertGameMode.mystery,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
