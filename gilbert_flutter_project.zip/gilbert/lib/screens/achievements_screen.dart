import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_colors.dart';
import '../models/player_profile.dart';
import '../providers/player_provider.dart';

class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key});

  int _currentValue(Achievement ach, profile) {
    switch (ach.metric) {
      case AchievementMetric.totalWordsFound:
        return profile.totalWordsFound;
      case AchievementMetric.totalBonusWordsFound:
        return profile.totalBonusWordsFound;
      case AchievementMetric.totalStars:
        return profile.totalStars;
      case AchievementMetric.loginStreak:
        return profile.loginStreak;
      case AchievementMetric.levelsCompleted:
        return (profile.currentWorldIndex - 1) * 15 +
            (profile.currentLevelIndex - 1);
    }
  }

  @override
  Widget build(BuildContext context) {
    final profile = context.watch<PlayerProvider>().profile;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Column(
            children: [
              AppBar(
                title: const Text('Achievements'),
                backgroundColor: Colors.transparent,
              ),
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: kAchievements.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final ach = kAchievements[i];
                    final unlocked =
                        profile.unlockedAchievementIds.contains(ach.id);
                    final current = _currentValue(ach, profile).clamp(0, ach.targetValue);
                    final progress = current / ach.targetValue;

                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.indigoMid,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: unlocked
                              ? AppColors.gilbertGold
                              : AppColors.cellBorder,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            unlocked
                                ? Icons.emoji_events_rounded
                                : Icons.emoji_events_outlined,
                            color: unlocked
                                ? AppColors.gilbertGold
                                : AppColors.textSecondary,
                            size: 32,
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(ach.title,
                                    style: const TextStyle(
                                        color: AppColors.textPrimary,
                                        fontWeight: FontWeight.w800)),
                                Text(ach.description,
                                    style: const TextStyle(
                                        color: AppColors.textSecondary,
                                        fontSize: 12)),
                                const SizedBox(height: 6),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: LinearProgressIndicator(
                                    value: progress,
                                    minHeight: 6,
                                    backgroundColor: AppColors.indigoNight,
                                    color: unlocked
                                        ? AppColors.gilbertGold
                                        : AppColors.streakCoral,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text('$current / ${ach.targetValue}',
                                    style: const TextStyle(
                                        color: AppColors.textSecondary,
                                        fontSize: 11)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
