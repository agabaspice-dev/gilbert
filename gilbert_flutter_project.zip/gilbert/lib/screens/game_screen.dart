import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_colors.dart';
import '../data/level_generator.dart';
import '../models/level.dart';
import '../providers/game_provider.dart';
import '../providers/player_provider.dart';
import '../widgets/coin_badge.dart';
import '../widgets/crossword_grid.dart';
import '../widgets/hint_and_streak_widgets.dart';
import '../widgets/letter_circle.dart';

enum GilbertGameMode { classic, daily, mystery }

class GameScreen extends StatefulWidget {
  final GilbertLevel? preloadedLevel;
  final int worldIndex;
  final int levelIndex;
  final GilbertGameMode mode;

  const GameScreen({
    super.key,
    this.preloadedLevel,
    this.worldIndex = 1,
    this.levelIndex = 1,
    this.mode = GilbertGameMode.classic,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late ConfettiController _confetti;
  String? _toastMessage;
  Color _toastColor = AppColors.success;

  @override
  void initState() {
    super.initState();
    _confetti = ConfettiController(duration: const Duration(seconds: 1));
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadLevel());
  }

  void _loadLevel() {
    final level = widget.preloadedLevel ??
        LevelGenerator.generateSingle(widget.worldIndex, widget.levelIndex);
    context.read<GameProvider>().loadLevel(level);
  }

  @override
  void dispose() {
    _confetti.dispose();
    super.dispose();
  }

  void _showToast(String message, Color color) {
    setState(() {
      _toastMessage = message;
      _toastColor = color;
    });
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _toastMessage = null);
    });
  }

  void _onReleased() {
    final gameProvider = context.read<GameProvider>();
    final playerProvider = context.read<PlayerProvider>();
    final result = gameProvider.submitCurrentWord(playerProvider);

    switch (result) {
      case WordSubmitResult.mainWord:
        _showToast('Nice! +coins', AppColors.success);
        if (gameProvider.isBoardComplete) {
          _confetti.play();
          playerProvider.registerStarsEarned(
              gameProvider.starsForCurrentLevel());
          Future.delayed(const Duration(milliseconds: 700), () {
            if (mounted) _showLevelCompleteSheet();
          });
        }
        break;
      case WordSubmitResult.bonusWord:
        _showToast('Mystery word found! +15', AppColors.cellBonus);
        break;
      case WordSubmitResult.alreadyFound:
        _showToast('Already found', AppColors.textSecondary);
        break;
      case WordSubmitResult.notAWord:
        _showToast('Not in the puzzle', AppColors.error);
        break;
      case WordSubmitResult.none:
        break;
    }
    gameProvider.clearSelection();
  }

  void _showLevelCompleteSheet() {
    final gameProvider = context.read<GameProvider>();
    final playerProvider = context.read<PlayerProvider>();
    playerProvider.registerLevelCompleted(
        gameProvider.level.worldIndex, gameProvider.level.levelIndex);

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.indigoNight,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.emoji_events_rounded,
                color: AppColors.gilbertGold, size: 56),
            const SizedBox(height: 12),
            Text('Level Complete!',
                style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                3,
                (i) => Icon(
                  Icons.star_rounded,
                  size: 36,
                  color: i < gameProvider.starsForCurrentLevel()
                      ? AppColors.gilbertGold
                      : AppColors.textSecondary.withOpacity(0.3),
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: const Text('Continue'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Consumer<GameProvider>(
            builder: (context, gameProvider, _) {
              if (!gameProvider.isLoaded) {
                return const Center(
                  child: CircularProgressIndicator(color: AppColors.gilbertGold),
                );
              }
              final playerProvider = context.watch<PlayerProvider>();

              return Stack(
                children: [
                  Column(
                    children: [
                      _buildTopBar(context, gameProvider, playerProvider),
                      const SizedBox(height: 12),
                      Expanded(
                        child: Center(
                          child: SingleChildScrollView(
                            child: CrosswordGrid(
                              level: gameProvider.level,
                              foundWords: gameProvider.foundBoardWords,
                            ),
                          ),
                        ),
                      ),
                      if (_toastMessage != null)
                        AnimatedOpacity(
                          opacity: 1,
                          duration: const Duration(milliseconds: 200),
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 8),
                            decoration: BoxDecoration(
                              color: _toastColor.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(_toastMessage!,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Text(
                          gameProvider.currentTrace,
                          style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary,
                            letterSpacing: 4,
                          ),
                        ),
                      ),
                      LetterCircle(
                        letters: gameProvider.level.letters,
                        selectedIndices: gameProvider.selectedIndices,
                        onLetterEntered: gameProvider.dragToLetter,
                        onReleased: _onReleased,
                      ),
                      const SizedBox(height: 16),
                      _buildHintBar(context, gameProvider, playerProvider),
                      const SizedBox(height: 16),
                    ],
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: ConfettiWidget(
                      confettiController: _confetti,
                      blastDirectionality: BlastDirectionality.explosive,
                      numberOfParticles: 24,
                      colors: const [
                        AppColors.gilbertGold,
                        AppColors.cellBonus,
                        AppColors.streakCoral,
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context, GameProvider gameProvider,
      PlayerProvider playerProvider) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: AppColors.textPrimary),
          ),
          Expanded(
            child: Text(
              widget.mode == GilbertGameMode.daily
                  ? 'Daily Challenge'
                  : 'World ${gameProvider.level.worldIndex} · Level ${gameProvider.level.levelIndex}',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: AppColors.textPrimary, fontWeight: FontWeight.w700),
            ),
          ),
          CoinBadge(coins: playerProvider.profile.coins),
          const SizedBox(width: 8),
        ],
      ),
    );
  }

  Widget _buildHintBar(BuildContext context, GameProvider gameProvider,
      PlayerProvider playerProvider) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        HintButton(
          icon: Icons.lightbulb_outline_rounded,
          label: 'Letter',
          cost: 25,
          onTap: () async {
            final ok = await gameProvider.useLetterHint(playerProvider);
            if (!ok && mounted) _showToast('Not enough coins', AppColors.error);
          },
        ),
        const SizedBox(width: 12),
        HintButton(
          icon: Icons.visibility_rounded,
          label: 'Reveal Word',
          cost: 60,
          onTap: () async {
            final ok = await gameProvider.useRevealWordHint(playerProvider);
            if (!ok && mounted) _showToast('Not enough coins', AppColors.error);
          },
        ),
      ],
    );
  }
}
