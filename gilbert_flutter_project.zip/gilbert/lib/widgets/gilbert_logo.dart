import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../core/theme/app_colors.dart';

/// The Gilbert brand mark: a gold circular medallion with a stylized "G"
/// built from a letter-tile motif (a small nod to the core swipe-connect
/// mechanic). Fully vector — scales to any size, no image assets required.
/// A designer can later reskin this into final app-icon artwork using the
/// same shapes/colors defined here and in AppColors.
class GilbertLogo extends StatelessWidget {
  final double size;
  final bool showWordmark;

  const GilbertLogo({super.key, this.size = 96, this.showWordmark = false});

  @override
  Widget build(BuildContext context) {
    final medallion = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: AppColors.goldGradient,
        boxShadow: [
          BoxShadow(
            color: AppColors.gilbertGold.withOpacity(0.45),
            blurRadius: size * 0.25,
            spreadRadius: 1,
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Container(
        width: size * 0.78,
        height: size * 0.78,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppColors.indigoDeep,
          border: Border.all(
            color: AppColors.indigoDeep.withOpacity(0.6),
            width: size * 0.02,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          'G',
          style: GoogleFonts.baloo2(
            fontSize: size * 0.46,
            fontWeight: FontWeight.w700,
            color: AppColors.gilbertGold,
            height: 1,
          ),
        ),
      ),
    );

    if (!showWordmark) return medallion;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        medallion,
        SizedBox(height: size * 0.12),
        Text(
          'GILBERT',
          style: GoogleFonts.baloo2(
            fontSize: size * 0.26,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
            letterSpacing: 3,
          ),
        ),
      ],
    );
  }
}
