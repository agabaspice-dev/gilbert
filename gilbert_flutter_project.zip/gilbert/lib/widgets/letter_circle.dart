import 'dart:math';
import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

/// The signature Gilbert interaction: a ring of letters the player swipes
/// across to spell words. Handles touch tracking, letter-hit testing, and
/// animated connector lines between selected letters.
class LetterCircle extends StatefulWidget {
  final List<String> letters;
  final List<int> selectedIndices;
  final void Function(int index) onLetterEntered;
  final VoidCallback onReleased;
  final double size;

  const LetterCircle({
    super.key,
    required this.letters,
    required this.selectedIndices,
    required this.onLetterEntered,
    required this.onReleased,
    this.size = 300,
  });

  @override
  State<LetterCircle> createState() => _LetterCircleState();
}

class _LetterCircleState extends State<LetterCircle>
    with SingleTickerProviderStateMixin {
  Offset? _dragPosition;
  late List<Offset> _letterPositions;

  @override
  void initState() {
    super.initState();
    _computePositions();
  }

  @override
  void didUpdateWidget(covariant LetterCircle oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.letters.length != widget.letters.length) {
      _computePositions();
    }
  }

  void _computePositions() {
    final n = widget.letters.length;
    final radius = widget.size / 2 - 34;
    _letterPositions = List.generate(n, (i) {
      final angle = (2 * pi * i / n) - pi / 2;
      return Offset(cos(angle) * radius, sin(angle) * radius);
    });
  }

  int? _hitTest(Offset localPos) {
    final center = Offset(widget.size / 2, widget.size / 2);
    for (int i = 0; i < _letterPositions.length; i++) {
      final letterCenter = center + _letterPositions[i];
      if ((localPos - letterCenter).distance < 28) return i;
    }
    return null;
  }

  void _handlePanStart(DragStartDetails details) {
    final hit = _hitTest(details.localPosition);
    setState(() => _dragPosition = details.localPosition);
    if (hit != null) widget.onLetterEntered(hit);
  }

  void _handlePanUpdate(DragUpdateDetails details) {
    setState(() => _dragPosition = details.localPosition);
    final hit = _hitTest(details.localPosition);
    if (hit != null) widget.onLetterEntered(hit);
  }

  void _handlePanEnd(DragEndDetails details) {
    setState(() => _dragPosition = null);
    widget.onReleased();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: _handlePanStart,
      onPanUpdate: _handlePanUpdate,
      onPanEnd: _handlePanEnd,
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: CustomPaint(
          painter: _TracePainter(
            letterPositions: _letterPositions,
            selectedIndices: widget.selectedIndices,
            center: Offset(widget.size / 2, widget.size / 2),
            liveDragPoint: _dragPosition,
          ),
          child: Stack(
            children: [
              for (int i = 0; i < widget.letters.length; i++)
                _LetterNode(
                  offset: Offset(widget.size / 2, widget.size / 2) +
                      _letterPositions[i],
                  letter: widget.letters[i],
                  isActive: widget.selectedIndices.contains(i),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LetterNode extends StatelessWidget {
  final Offset offset;
  final String letter;
  final bool isActive;

  const _LetterNode({
    required this.offset,
    required this.letter,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: offset.dx - 28,
      top: offset.dy - 28,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        curve: Curves.easeOut,
        width: 56,
        height: 56,
        transform: Matrix4.identity()..scale(isActive ? 1.12 : 1.0),
        transformAlignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isActive ? AppColors.letterFillActive : AppColors.letterFill,
          boxShadow: [
            BoxShadow(
              color: (isActive ? AppColors.gilbertGold : Colors.black)
                  .withOpacity(isActive ? 0.45 : 0.25),
              blurRadius: isActive ? 16 : 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        alignment: Alignment.center,
        child: Text(
          letter,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w800,
            color: isActive
                ? AppColors.letterTextActive
                : AppColors.letterText,
          ),
        ),
      ),
    );
  }
}

class _TracePainter extends CustomPainter {
  final List<Offset> letterPositions;
  final List<int> selectedIndices;
  final Offset center;
  final Offset? liveDragPoint;

  _TracePainter({
    required this.letterPositions,
    required this.selectedIndices,
    required this.center,
    required this.liveDragPoint,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (selectedIndices.isEmpty) return;
    final paint = Paint()
      ..color = AppColors.traceLine
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final path = Path();
    final first = center + letterPositions[selectedIndices.first];
    path.moveTo(first.dx, first.dy);
    for (int i = 1; i < selectedIndices.length; i++) {
      final p = center + letterPositions[selectedIndices[i]];
      path.lineTo(p.dx, p.dy);
    }
    if (liveDragPoint != null) {
      path.lineTo(liveDragPoint!.dx, liveDragPoint!.dy);
    }
    canvas.drawPath(
      path,
      paint..color = AppColors.traceLine.withOpacity(0.85),
    );
  }

  @override
  bool shouldRepaint(covariant _TracePainter oldDelegate) => true;
}
