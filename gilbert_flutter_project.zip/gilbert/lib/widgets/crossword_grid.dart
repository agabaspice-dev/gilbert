import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../models/level.dart';

/// Renders the crossword-style board: a grid where each placed word's
/// cells are either empty (unsolved) or filled with letters once the
/// player finds that word in the letter circle.
class CrosswordGrid extends StatelessWidget {
  final GilbertLevel level;
  final Set<String> foundWords;
  final double cellSize;

  const CrosswordGrid({
    super.key,
    required this.level,
    required this.foundWords,
    this.cellSize = 38,
  });

  @override
  Widget build(BuildContext context) {
    // Map each (row, col) -> letter + whether revealed.
    final cellLetter = <String, String>{};
    final cellRevealed = <String, bool>{};

    for (final w in level.boardWords) {
      final isFound = foundWords.contains(w.word);
      final cells = w.cells;
      for (int i = 0; i < cells.length; i++) {
        final key = '${cells[i][0]}_${cells[i][1]}';
        cellLetter[key] = w.word[i];
        cellRevealed[key] = (cellRevealed[key] ?? false) || isFound;
      }
    }

    return SizedBox(
      width: level.gridCols * cellSize,
      height: level.gridRows * cellSize,
      child: Stack(
        children: [
          for (int r = 0; r < level.gridRows; r++)
            for (int c = 0; c < level.gridCols; c++)
              if (cellLetter.containsKey('${r}_$c'))
                Positioned(
                  left: c * cellSize,
                  top: r * cellSize,
                  child: _GridCell(
                    size: cellSize,
                    letter: cellLetter['${r}_$c']!,
                    revealed: cellRevealed['${r}_$c']!,
                  ),
                ),
        ],
      ),
    );
  }
}

class _GridCell extends StatelessWidget {
  final double size;
  final String letter;
  final bool revealed;

  const _GridCell({
    required this.size,
    required this.letter,
    required this.revealed,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutBack,
      width: size - 3,
      height: size - 3,
      margin: const EdgeInsets.all(1.5),
      decoration: BoxDecoration(
        color: revealed ? AppColors.cellFilled : AppColors.cellEmpty,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppColors.cellBorder, width: 1),
      ),
      alignment: Alignment.center,
      child: revealed
          ? Text(
              letter,
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 18,
                color: AppColors.textOnGold,
              ),
            )
          : null,
    );
  }
}
