import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

class LevelNode extends StatelessWidget {
  final int levelIndex;
  final bool isLocked;
  final bool isCurrent;
  final int stars; // 0-3
  final VoidCallback? onTap;

  const LevelNode({
    super.key,
    required this.levelIndex,
    required this.isLocked,
    required this.isCurrent,
    required this.stars,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final Color bg = isLocked
        ? AppColors.indigoMid
        : (isCurrent ? AppColors.gilbertGold : AppColors.cellFilled);

    return GestureDetector(
      onTap: isLocked ? null : onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: bg,
              border: isCurrent
                  ? Border.all(color: Colors.white, width: 3)
                  : null,
              boxShadow: isCurrent
                  ? [
                      BoxShadow(
                        color: AppColors.gilbertGold.withOpacity(0.5),
                        blurRadius: 14,
                      ),
                    ]
                  : null,
            ),
            alignment: Alignment.center,
            child: isLocked
                ? const Icon(Icons.lock_rounded,
                    color: AppColors.textSecondary, size: 22)
                : Text(
                    '$levelIndex',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                      color: isCurrent
                          ? AppColors.textOnGold
                          : AppColors.indigoDeep,
                    ),
                  ),
          ),
          if (!isLocked && stars > 0) ...[
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(
                3,
                (i) => Icon(
                  Icons.star_rounded,
                  size: 14,
                  color: i < stars
                      ? AppColors.gilbertGold
                      : AppColors.textSecondary.withOpacity(0.3),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
