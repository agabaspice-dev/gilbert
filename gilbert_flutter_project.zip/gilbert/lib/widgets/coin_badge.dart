import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

class CoinBadge extends StatelessWidget {
  final int coins;
  final VoidCallback? onTap;

  const CoinBadge({super.key, required this.coins, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: AppColors.indigoMid,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.gilbertGold.withOpacity(0.4)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.monetization_on_rounded,
                color: AppColors.coin, size: 20),
            const SizedBox(width: 6),
            Text(
              '$coins',
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w800,
                fontSize: 15,
              ),
            ),
            if (onTap != null) ...[
              const SizedBox(width: 4),
              const Icon(Icons.add_circle,
                  color: AppColors.gilbertGold, size: 16),
            ],
          ],
        ),
      ),
    );
  }
}
