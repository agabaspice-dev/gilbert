import 'package:flutter/material.dart';

/// Gilbert brand palette.
/// Identity: deep indigo-night background, warm gold accent (the "Gilbert
/// gold"), soft mint success color, and a warm coral for streaks/energy.
/// This mirrors the premium, elegant feel of top word-puzzle games while
/// staying distinct via the gold-on-indigo signature.
class AppColors {
  AppColors._();

  // Brand core
  static const Color gilbertGold = Color(0xFFF3C34B);
  static const Color gilbertGoldDeep = Color(0xFFD9A431);
  static const Color indigoNight = Color(0xFF141A35);
  static const Color indigoDeep = Color(0xFF0B0E22);
  static const Color indigoMid = Color(0xFF232B57);

  // Board / letters
  static const Color letterCircleBg = Color(0xFF1D2547);
  static const Color letterFill = Color(0xFFFFFFFF);
  static const Color letterFillActive = gilbertGold;
  static const Color letterText = indigoDeep;
  static const Color letterTextActive = indigoDeep;
  static const Color traceLine = gilbertGold;

  // Board cells
  static const Color cellEmpty = Color(0xFF2A3260);
  static const Color cellFilled = Color(0xFFFFFFFF);
  static const Color cellBonus = Color(0xFF7CE0C3);
  static const Color cellBorder = Color(0xFF3A4270);

  // Semantic
  static const Color success = Color(0xFF63D9A6);
  static const Color streakCoral = Color(0xFFFF7A5C);
  static const Color error = Color(0xFFE5566B);
  static const Color coin = gilbertGold;

  // Text
  static const Color textPrimary = Color(0xFFF7F7FB);
  static const Color textSecondary = Color(0xFFA7ACC9);
  static const Color textOnGold = indigoDeep;

  static const LinearGradient backgroundGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [indigoDeep, indigoNight, indigoMid],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [gilbertGold, gilbertGoldDeep],
  );
}
