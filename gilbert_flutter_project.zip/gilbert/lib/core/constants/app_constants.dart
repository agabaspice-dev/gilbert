class AppConstants {
  AppConstants._();

  static const String appName = 'Gilbert';

  // Economy
  static const int coinsPerLetterOfMainWord = 2;
  static const int coinsPerBonusWord = 15;
  static const int coinsLevelClearBonus = 30;
  static const int coinsDailyLoginBase = 20;
  static const int coinsSpeedModeWordBase = 10;
  static const int hintCostReveealLetter = 25;
  static const int hintCostRevealWord = 60;
  static const int dailyChallengeCompletionCoins = 100;

  // Streaks
  static const int maxDailyStreakBonusDay = 7;

  // Speed mode
  static const int speedModeRoundSeconds = 90;

  // Level generation
  static const int worldsCount = 200; // "hundreds of worlds"
  static const int levelsPerWorld = 15; // -> 3000 levels total
  static const int minWordLength = 3;
  static const int maxLetterCircleSize = 9;

  // Persistence keys
  static const String prefsPlayerProfile = 'gilbert_player_profile_v1';
  static const String prefsLevelProgress = 'gilbert_level_progress_v1';
  static const String prefsDailyState = 'gilbert_daily_state_v1';
  static const String prefsSettings = 'gilbert_settings_v1';
}
