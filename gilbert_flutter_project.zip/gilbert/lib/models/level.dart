import 'dart:convert';

/// A single placed word on the crossword-style board.
class PlacedWord {
  final String word; // uppercase answer
  final int row;
  final int col;
  final bool isHorizontal;

  const PlacedWord({
    required this.word,
    required this.row,
    required this.col,
    required this.isHorizontal,
  });

  /// All (row, col) grid coordinates this word occupies, in order.
  List<List<int>> get cells {
    final List<List<int>> out = [];
    for (int i = 0; i < word.length; i++) {
      out.add(isHorizontal ? [row, col + i] : [row + i, col]);
    }
    return out;
  }

  Map<String, dynamic> toJson() => {
        'word': word,
        'row': row,
        'col': col,
        'isHorizontal': isHorizontal,
      };

  factory PlacedWord.fromJson(Map<String, dynamic> json) => PlacedWord(
        word: json['word'],
        row: json['row'],
        col: json['col'],
        isHorizontal: json['isHorizontal'],
      );
}

/// A full puzzle level: a set of intersecting board words drawn from a
/// scrambled letter set, plus optional bonus/"mystery" words that are also
/// formable from the same letters but are not placed on the board.
class GilbertLevel {
  final String id;
  final int worldIndex;
  final int levelIndex; // 1-based within world
  final List<String> letters; // scrambled circle letters
  final List<PlacedWord> boardWords;
  final List<String> bonusWords; // extra valid words for coin rewards
  final int gridRows;
  final int gridCols;

  const GilbertLevel({
    required this.id,
    required this.worldIndex,
    required this.levelIndex,
    required this.letters,
    required this.boardWords,
    required this.bonusWords,
    required this.gridRows,
    required this.gridCols,
  });

  int get difficultyScore =>
      boardWords.fold(0, (sum, w) => sum + w.word.length) +
      bonusWords.length;

  Map<String, dynamic> toJson() => {
        'id': id,
        'worldIndex': worldIndex,
        'levelIndex': levelIndex,
        'letters': letters,
        'boardWords': boardWords.map((w) => w.toJson()).toList(),
        'bonusWords': bonusWords,
        'gridRows': gridRows,
        'gridCols': gridCols,
      };

  factory GilbertLevel.fromJson(Map<String, dynamic> json) => GilbertLevel(
        id: json['id'],
        worldIndex: json['worldIndex'],
        levelIndex: json['levelIndex'],
        letters: List<String>.from(json['letters']),
        boardWords: (json['boardWords'] as List)
            .map((w) => PlacedWord.fromJson(w))
            .toList(),
        bonusWords: List<String>.from(json['bonusWords']),
        gridRows: json['gridRows'],
        gridCols: json['gridCols'],
      );

  String encode() => jsonEncode(toJson());
  factory GilbertLevel.decode(String s) =>
      GilbertLevel.fromJson(jsonDecode(s));
}

/// Runtime + persisted progress for one level.
class LevelProgress {
  final String levelId;
  final Set<String> foundBoardWords;
  final Set<String> foundBonusWords;
  final int starsEarned; // 0-3
  final bool completed;

  const LevelProgress({
    required this.levelId,
    this.foundBoardWords = const {},
    this.foundBonusWords = const {},
    this.starsEarned = 0,
    this.completed = false,
  });

  LevelProgress copyWith({
    Set<String>? foundBoardWords,
    Set<String>? foundBonusWords,
    int? starsEarned,
    bool? completed,
  }) =>
      LevelProgress(
        levelId: levelId,
        foundBoardWords: foundBoardWords ?? this.foundBoardWords,
        foundBonusWords: foundBonusWords ?? this.foundBonusWords,
        starsEarned: starsEarned ?? this.starsEarned,
        completed: completed ?? this.completed,
      );

  Map<String, dynamic> toJson() => {
        'levelId': levelId,
        'foundBoardWords': foundBoardWords.toList(),
        'foundBonusWords': foundBonusWords.toList(),
        'starsEarned': starsEarned,
        'completed': completed,
      };

  factory LevelProgress.fromJson(Map<String, dynamic> json) => LevelProgress(
        levelId: json['levelId'],
        foundBoardWords: Set<String>.from(json['foundBoardWords']),
        foundBonusWords: Set<String>.from(json['foundBonusWords']),
        starsEarned: json['starsEarned'],
        completed: json['completed'],
      );
}
