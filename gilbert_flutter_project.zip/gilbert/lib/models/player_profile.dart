class PlayerProfile {
  final String playerId;
  String displayName;
  int coins;
  int currentWorldIndex;
  int currentLevelIndex;
  int totalStars;
  int loginStreak;
  DateTime? lastLoginDate;
  int totalWordsFound;
  int totalBonusWordsFound;
  Set<String> unlockedAchievementIds;

  PlayerProfile({
    required this.playerId,
    this.displayName = 'Player',
    this.coins = 100,
    this.currentWorldIndex = 1,
    this.currentLevelIndex = 1,
    this.totalStars = 0,
    this.loginStreak = 0,
    this.lastLoginDate,
    this.totalWordsFound = 0,
    this.totalBonusWordsFound = 0,
    Set<String>? unlockedAchievementIds,
  }) : unlockedAchievementIds = unlockedAchievementIds ?? {};

  Map<String, dynamic> toJson() => {
        'playerId': playerId,
        'displayName': displayName,
        'coins': coins,
        'currentWorldIndex': currentWorldIndex,
        'currentLevelIndex': currentLevelIndex,
        'totalStars': totalStars,
        'loginStreak': loginStreak,
        'lastLoginDate': lastLoginDate?.toIso8601String(),
        'totalWordsFound': totalWordsFound,
        'totalBonusWordsFound': totalBonusWordsFound,
        'unlockedAchievementIds': unlockedAchievementIds.toList(),
      };

  factory PlayerProfile.fromJson(Map<String, dynamic> json) => PlayerProfile(
        playerId: json['playerId'],
        displayName: json['displayName'] ?? 'Player',
        coins: json['coins'] ?? 100,
        currentWorldIndex: json['currentWorldIndex'] ?? 1,
        currentLevelIndex: json['currentLevelIndex'] ?? 1,
        totalStars: json['totalStars'] ?? 0,
        loginStreak: json['loginStreak'] ?? 0,
        lastLoginDate: json['lastLoginDate'] != null
            ? DateTime.parse(json['lastLoginDate'])
            : null,
        totalWordsFound: json['totalWordsFound'] ?? 0,
        totalBonusWordsFound: json['totalBonusWordsFound'] ?? 0,
        unlockedAchievementIds:
            Set<String>.from(json['unlockedAchievementIds'] ?? []),
      );
}

class Achievement {
  final String id;
  final String title;
  final String description;
  final int targetValue;
  final AchievementMetric metric;
  final int coinReward;

  const Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.targetValue,
    required this.metric,
    required this.coinReward,
  });
}

enum AchievementMetric {
  totalWordsFound,
  totalBonusWordsFound,
  totalStars,
  loginStreak,
  levelsCompleted,
}

const List<Achievement> kAchievements = [
  Achievement(
    id: 'ach_first_word',
    title: 'First Steps',
    description: 'Find your first word',
    targetValue: 1,
    metric: AchievementMetric.totalWordsFound,
    coinReward: 20,
  ),
  Achievement(
    id: 'ach_wordsmith',
    title: 'Wordsmith',
    description: 'Find 250 words',
    targetValue: 250,
    metric: AchievementMetric.totalWordsFound,
    coinReward: 150,
  ),
  Achievement(
    id: 'ach_treasure_hunter',
    title: 'Treasure Hunter',
    description: 'Discover 50 bonus mystery words',
    targetValue: 50,
    metric: AchievementMetric.totalBonusWordsFound,
    coinReward: 200,
  ),
  Achievement(
    id: 'ach_star_collector',
    title: 'Star Collector',
    description: 'Earn 100 stars',
    targetValue: 100,
    metric: AchievementMetric.totalStars,
    coinReward: 250,
  ),
  Achievement(
    id: 'ach_week_streak',
    title: 'On a Roll',
    description: 'Log in 7 days in a row',
    targetValue: 7,
    metric: AchievementMetric.loginStreak,
    coinReward: 100,
  ),
  Achievement(
    id: 'ach_explorer',
    title: 'World Explorer',
    description: 'Complete 100 levels',
    targetValue: 100,
    metric: AchievementMetric.levelsCompleted,
    coinReward: 300,
  ),
];
