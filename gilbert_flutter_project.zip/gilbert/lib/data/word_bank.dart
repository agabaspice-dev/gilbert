/// Seed dictionary for procedural level generation, grouped into difficulty
/// tiers. In production this should be swapped for a large curated word list
/// (see LevelGenerator doc comment for how to source one), but the generator
/// itself works with any word list of this shape.
///
/// Words are uppercase, 3-9 letters, common English vocabulary suitable for
/// a family-friendly puzzle game.
class WordBank {
  WordBank._();

  static const List<String> tier1 = [
    'CAT', 'DOG', 'SUN', 'HAT', 'CAR', 'BEE', 'PEN', 'CUP', 'BAT', 'RUG',
    'ARM', 'EAR', 'EYE', 'ICE', 'JAM', 'KEY', 'LEG', 'MAP', 'NET', 'OWL',
    'PIG', 'RAT', 'SEA', 'TEA', 'VAN', 'WEB', 'ZOO', 'AGE', 'AIR', 'ANT',
  ];

  static const List<String> tier2 = [
    'APPLE', 'BEACH', 'CHAIR', 'DANCE', 'EAGLE', 'FLAME', 'GRAPE', 'HOUSE',
    'IMAGE', 'JOLLY', 'KNIFE', 'LEMON', 'MUSIC', 'NURSE', 'OCEAN', 'PIANO',
    'QUEEN', 'RIVER', 'STONE', 'TIGER', 'UNCLE', 'VOICE', 'WATER', 'YOUTH',
    'ZEBRA', 'BREAD', 'CLOUD', 'DREAM', 'EARTH', 'FRUIT', 'GHOST', 'HONEY',
  ];

  static const List<String> tier3 = [
    'GARDEN', 'FOREST', 'ISLAND', 'JUNGLE', 'KETTLE', 'LANTERN', 'MARKET',
    'NATURE', 'ORANGE', 'PALACE', 'QUARTZ', 'RABBIT', 'SILVER', 'TEMPLE',
    'UMBRELLA', 'VELVET', 'WINTER', 'YELLOW', 'ZODIAC', 'BRIDGE', 'CASTLE',
    'DIAMOND', 'ENGINE', 'FALCON', 'GALAXY', 'HARBOR', 'IGLOO', 'JOURNEY',
  ];

  static const List<String> tier4 = [
    'ADVENTURE', 'BUTTERFLY', 'CHOCOLATE', 'DISCOVERY', 'ELEPHANT',
    'FIREPLACE', 'GRATITUDE', 'HORIZON', 'INVENTION', 'JOYFULLY',
    'KINGDOM', 'LANDSCAPE', 'MOUNTAIN', 'NAVIGATE', 'ORCHESTRA',
    'PARADISE', 'QUICKSAND', 'RAINBOW', 'SUNFLOWER', 'TREASURE',
    'UNIVERSE', 'VOYAGE', 'WATERFALL', 'XYLOPHONE', 'YESTERDAY', 'ZEPHYR',
  ];

  static List<String> forWorld(int worldIndex) {
    // Progressive difficulty: early worlds lean short words, later worlds
    // mix in longer ones, mirroring "progressively harder levels".
    if (worldIndex <= 5) return [...tier1, ...tier2];
    if (worldIndex <= 12) return [...tier2, ...tier3];
    if (worldIndex <= 20) return [...tier3, ...tier4];
    return [...tier2, ...tier3, ...tier4];
  }
}
