import 'dart:math';
import '../core/constants/app_constants.dart';
import '../models/level.dart';
import 'word_bank.dart';

/// Procedurally generates Gilbert levels.
///
/// Design notes — "AI to generate new puzzles automatically":
/// This generator is a deterministic, seedable algorithm (no network call,
/// works fully offline, instant, infinitely repeatable) that can produce
/// effectively unlimited unique levels from a word list. That is what
/// actually ships inside the app.
///
/// To layer real generative-AI content on top (e.g. themed word packs,
/// seasonal events, localized word lists), run an OFFLINE authoring
/// pipeline: call an LLM (e.g. the Claude API) to produce a themed word
/// list + validate each word against a dictionary, then feed that list
/// into `LevelGenerator.generateWorld()` below exactly like `WordBank`.
/// Keep AI calls out of the runtime hot path on-device — generate content
/// server-side/offline, ship it as data, and let this deterministic
/// algorithm turn word lists into playable, guaranteed-solvable levels.
class LevelGenerator {
  LevelGenerator._();

  static const int _gridSize = 9;

  /// Generates every level for a given world (1-indexed).
  static List<GilbertLevel> generateWorld(int worldIndex) {
    final words = WordBank.forWorld(worldIndex);
    final rng = Random(worldIndex * 7919); // deterministic per-world seed
    final levels = <GilbertLevel>[];

    for (int levelIndex = 1;
        levelIndex <= AppConstants.levelsPerWorld;
        levelIndex++) {
      final seed = worldIndex * 100000 + levelIndex;
      levels.add(_generateLevel(
        worldIndex: worldIndex,
        levelIndex: levelIndex,
        words: words,
        rng: Random(seed),
        difficultyRamp: levelIndex / AppConstants.levelsPerWorld,
      ));
    }
    return levels;
  }

  static GilbertLevel generateSingle(int worldIndex, int levelIndex) {
    final words = WordBank.forWorld(worldIndex);
    final seed = worldIndex * 100000 + levelIndex;
    return _generateLevel(
      worldIndex: worldIndex,
      levelIndex: levelIndex,
      words: words,
      rng: Random(seed),
      difficultyRamp: levelIndex / AppConstants.levelsPerWorld,
    );
  }

  /// Special generator for Daily Challenge — seeded by the calendar date so
  /// every player gets the identical puzzle on a given day.
  static GilbertLevel generateDaily(DateTime date) {
    final seed = date.year * 10000 + date.month * 100 + date.day;
    final words = [...WordBank.tier2, ...WordBank.tier3];
    return _generateLevel(
      worldIndex: 0,
      levelIndex: 0,
      words: words,
      rng: Random(seed),
      difficultyRamp: 0.6,
      idOverride: 'daily_${date.year}_${date.month}_${date.day}',
    );
  }

  static GilbertLevel _generateLevel({
    required int worldIndex,
    required int levelIndex,
    required List<String> words,
    required Random rng,
    required double difficultyRamp,
    String? idOverride,
  }) {
    // 1. Pick a base "anchor" word. Longer as difficulty ramps up.
    final pool = List<String>.from(words)..shuffle(rng);
    final targetLen = (4 + (difficultyRamp * 5)).round().clamp(3, 9);
    String anchor = pool.firstWhere(
      (w) => w.length >= targetLen,
      orElse: () => pool.reduce((a, b) => a.length > b.length ? a : b),
    );

    // 2. Build the letter multiset for this level from the anchor word,
    // padded with a couple of extra common letters for richer bonus words.
    final letterCounts = <String, int>{};
    for (final ch in anchor.split('')) {
      letterCounts[ch] = (letterCounts[ch] ?? 0) + 1;
    }
    final extraLetters = 'ETAOINSRLH'.split('')..shuffle(rng);
    int extrasToAdd = (2 + rng.nextInt(2));
    for (final ch in extraLetters) {
      if (extrasToAdd <= 0) break;
      if (letterCounts.length + 1 > AppConstants.maxLetterCircleSize) break;
      letterCounts[ch] = (letterCounts[ch] ?? 0) + 1;
      extrasToAdd--;
    }

    // 3. Find every word in the pool that is formable from this letter
    // multiset (candidate board + bonus words).
    final formable = pool
        .where((w) => w != anchor && _isFormable(w, letterCounts))
        .toSet()
        .toList()
      ..sort((a, b) => b.length.compareTo(a.length));

    // 4. Place words on the grid crossword-style, starting with the anchor.
    final grid = List.generate(_gridSize, (_) => List.filled(_gridSize, ''));
    final placed = <PlacedWord>[];
    final startRow = _gridSize ~/ 2;
    final startCol = max(0, (_gridSize - anchor.length) ~/ 2);
    _place(grid, placed, anchor, startRow, startCol, true);

    final boardTargetCount = 3 + (difficultyRamp * 4).round(); // 3-7 words
    for (final candidate in formable) {
      if (placed.length >= boardTargetCount) break;
      final spot = _findIntersection(grid, placed, candidate);
      if (spot != null) {
        _place(grid, placed, candidate, spot[0], spot[1], spot[2] == 1);
      }
    }

    // 5. Normalize placement to a tight bounding box.
    final normalized = _normalize(placed);

    // 6. Remaining formable words that didn't make the board become bonus
    // ("mystery") words — the hidden-word reward system.
    final placedWordsSet = normalized.map((w) => w.word).toSet();
    final bonusWords = formable
        .where((w) => !placedWordsSet.contains(w) && w.length >= 3)
        .take(6)
        .toList();

    // 7. Scramble letters for the circle.
    final circleLetters = letterCounts.entries
        .expand((e) => List.filled(e.value, e.key))
        .toList()
      ..shuffle(rng);

    final bbox = _boundingBox(normalized);

    return GilbertLevel(
      id: idOverride ?? 'w${worldIndex}_l$levelIndex',
      worldIndex: worldIndex,
      levelIndex: levelIndex,
      letters: circleLetters,
      boardWords: normalized,
      bonusWords: bonusWords,
      gridRows: bbox[0],
      gridCols: bbox[1],
    );
  }

  static bool _isFormable(String word, Map<String, int> letterCounts) {
    final need = <String, int>{};
    for (final ch in word.split('')) {
      need[ch] = (need[ch] ?? 0) + 1;
    }
    for (final entry in need.entries) {
      if ((letterCounts[entry.key] ?? 0) < entry.value) return false;
    }
    return true;
  }

  static void _place(List<List<String>> grid, List<PlacedWord> placed,
      String word, int row, int col, bool horizontal) {
    for (int i = 0; i < word.length; i++) {
      final r = horizontal ? row : row + i;
      final c = horizontal ? col + i : col;
      if (r < 0 || r >= grid.length || c < 0 || c >= grid[0].length) return;
      grid[r][c] = word[i];
    }
    placed.add(PlacedWord(word: word, row: row, col: col, isHorizontal: horizontal));
  }

  /// Finds a valid (row, col, orientationFlag) placement for [candidate]
  /// that intersects an already-placed word on a shared letter, with no
  /// conflicting overlaps. orientationFlag: 1 = horizontal, 0 = vertical.
  static List<int>? _findIntersection(
      List<List<String>> grid, List<PlacedWord> placed, String candidate) {
    for (final existing in placed) {
      for (int ci = 0; ci < candidate.length; ci++) {
        for (int ei = 0; ei < existing.word.length; ei++) {
          if (candidate[ci] != existing.word[ei]) continue;

          final horizontal = !existing.isHorizontal; // cross the other way
          final row = existing.isHorizontal
              ? existing.row - ci
              : existing.row + ei;
          final col = existing.isHorizontal
              ? existing.col + ei
              : existing.col - ci;

          if (_canPlace(grid, candidate, row, col, horizontal)) {
            return [row, col, horizontal ? 1 : 0];
          }
        }
      }
    }
    return null;
  }

  static bool _canPlace(List<List<String>> grid, String word, int row,
      int col, bool horizontal) {
    for (int i = 0; i < word.length; i++) {
      final r = horizontal ? row : row + i;
      final c = horizontal ? col + i : col;
      if (r < 0 || r >= grid.length || c < 0 || c >= grid[0].length) {
        return false;
      }
      final existing = grid[r][c];
      if (existing.isNotEmpty && existing != word[i]) return false;
    }
    return true;
  }

  static List<PlacedWord> _normalize(List<PlacedWord> placed) {
    final minRow = placed.map((w) => w.row).reduce(min);
    final minCol = placed.map((w) => w.col).reduce(min);
    return placed
        .map((w) => PlacedWord(
              word: w.word,
              row: w.row - minRow,
              col: w.col - minCol,
              isHorizontal: w.isHorizontal,
            ))
        .toList();
  }

  static List<int> _boundingBox(List<PlacedWord> placed) {
    int maxRow = 0, maxCol = 0;
    for (final w in placed) {
      for (final cell in w.cells) {
        maxRow = max(maxRow, cell[0]);
        maxCol = max(maxCol, cell[1]);
      }
    }
    return [maxRow + 1, maxCol + 1];
  }
}
