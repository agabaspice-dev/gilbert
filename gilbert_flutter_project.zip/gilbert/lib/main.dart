import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'app.dart';
import 'services/ads_service.dart';
import 'services/iap_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // google_mobile_ads and in_app_purchase don't support Flutter Web, so
  // skip them entirely there (e.g. when deployed to Netlify/Vercel/etc.
  // as a browser demo). They still init normally on Android/iOS.
  if (!kIsWeb) {
    await AdsService.instance.init();
    await IapService.instance.init();
  }

  runApp(const GilbertApp());
}
