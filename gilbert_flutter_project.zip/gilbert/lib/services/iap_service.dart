import 'dart:async';
import 'package:in_app_purchase/in_app_purchase.dart';

/// SETUP REQUIRED before release:
/// 1. Create these product IDs in App Store Connect + Google Play Console:
///    - gilbert_coins_small, gilbert_coins_medium, gilbert_coins_large
///    - gilbert_remove_ads
///    - gilbert_premium_bundle (remove ads + coin starter pack)
/// 2. Call `IapService.instance.init()` at app start.
/// 3. Handle `purchaseStream` events to grant entitlements (see
///    PlayerProvider.grantPurchase).
class IapService {
  IapService._();
  static final IapService instance = IapService._();

  static const Set<String> productIds = {
    'gilbert_coins_small',
    'gilbert_coins_medium',
    'gilbert_coins_large',
    'gilbert_remove_ads',
    'gilbert_premium_bundle',
  };

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _subscription;
  List<ProductDetails> products = [];

  Stream<List<PurchaseDetails>> get purchaseStream => _iap.purchaseStream;

  Future<void> init() async {
    final available = await _iap.isAvailable();
    if (!available) return;
    final response = await _iap.queryProductDetails(productIds);
    products = response.productDetails;
  }

  Future<void> buy(ProductDetails product, {required bool consumable}) async {
    final purchaseParam = PurchaseParam(productDetails: product);
    if (consumable) {
      await _iap.buyConsumable(purchaseParam: purchaseParam);
    } else {
      await _iap.buyNonConsumable(purchaseParam: purchaseParam);
    }
  }

  Future<void> completePurchase(PurchaseDetails purchase) async {
    if (purchase.pendingCompletePurchase) {
      await _iap.completePurchase(purchase);
    }
  }

  void dispose() => _subscription?.cancel();
}
