import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants/app_constants.dart';
import '../models/level.dart';
import '../models/player_profile.dart';

/// Central local-persistence layer. Everything about the player lives on
/// device (no login required to play), which keeps the app fast and
/// works fully offline. Swap this for a cloud-synced backend later without
/// touching call sites — it's the single seam for save data.
class LocalStorageService {
  static SharedPreferences? _prefsInstance;

  static Future<SharedPreferences> get _prefs async {
    _prefsInstance ??= await SharedPreferences.getInstance();
    return _prefsInstance!;
  }

  static Future<PlayerProfile> loadOrCreateProfile() async {
    final prefs = await _prefs;
    final raw = prefs.getString(AppConstants.prefsPlayerProfile);
    if (raw != null) {
      return PlayerProfile.fromJson(jsonDecode(raw));
    }
    final fresh = PlayerProfile(
      playerId: DateTime.now().millisecondsSinceEpoch.toString(),
    );
    await saveProfile(fresh);
    return fresh;
  }

  static Future<void> saveProfile(PlayerProfile profile) async {
    final prefs = await _prefs;
    await prefs.setString(
        AppConstants.prefsPlayerProfile, jsonEncode(profile.toJson()));
  }

  static Future<Map<String, LevelProgress>> loadAllProgress() async {
    final prefs = await _prefs;
    final raw = prefs.getString(AppConstants.prefsLevelProgress);
    if (raw == null) return {};
    final Map<String, dynamic> decoded = jsonDecode(raw);
    return decoded
        .map((key, value) => MapEntry(key, LevelProgress.fromJson(value)));
  }

  static Future<void> saveProgress(
      Map<String, LevelProgress> progressMap) async {
    final prefs = await _prefs;
    final encoded = jsonEncode(
        progressMap.map((key, value) => MapEntry(key, value.toJson())));
    await prefs.setString(AppConstants.prefsLevelProgress, encoded);
  }

  static Future<Map<String, dynamic>> loadDailyState() async {
    final prefs = await _prefs;
    final raw = prefs.getString(AppConstants.prefsDailyState);
    if (raw == null) return {};
    return jsonDecode(raw);
  }

  static Future<void> saveDailyState(Map<String, dynamic> state) async {
    final prefs = await _prefs;
    await prefs.setString(AppConstants.prefsDailyState, jsonEncode(state));
  }
}
