import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Thin wrapper around google_mobile_ads.
///
/// SETUP REQUIRED before release:
/// 1. Create an AdMob app for iOS + Android and replace the test IDs below.
/// 2. Add your AdMob App ID to android/app/src/main/AndroidManifest.xml
///    and ios/Runner/Info.plist (com.google.android.gms.ads.APPLICATION_ID
///    / GADApplicationIdentifier). See README.md.
/// 3. Call `AdsService.instance.init()` once in main() before runApp.
class AdsService {
  AdsService._();
  static final AdsService instance = AdsService._();

  bool _initialized = false;
  RewardedAd? _rewardedAd;
  InterstitialAd? _interstitialAd;

  // Google test ad unit IDs — replace with real IDs before release.
  static const String _rewardedTestId =
      'ca-app-pub-3940256099942544/5224354917';
  static const String _interstitialTestId =
      'ca-app-pub-3940256099942544/1033173712';
  static const String _bannerTestId =
      'ca-app-pub-3940256099942544/6300978111';

  String get bannerAdUnitId => _bannerTestId;

  Future<void> init() async {
    if (_initialized) return;
    await MobileAds.instance.initialize();
    _initialized = true;
    _loadRewarded();
    _loadInterstitial();
  }

  void _loadRewarded() {
    RewardedAd.load(
      adUnitId: _rewardedTestId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => _rewardedAd = ad,
        onAdFailedToLoad: (_) => _rewardedAd = null,
      ),
    );
  }

  void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: _interstitialTestId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitialAd = ad,
        onAdFailedToLoad: (_) => _interstitialAd = null,
      ),
    );
  }

  /// Shows a rewarded ad (e.g. "watch ad for a free hint" / bonus coins).
  /// Returns true if the reward was actually earned.
  Future<bool> showRewarded() async {
    final ad = _rewardedAd;
    if (ad == null) return false;
    bool earned = false;
    await ad.show(onUserEarnedReward: (_, __) => earned = true);
    _rewardedAd = null;
    _loadRewarded();
    return earned;
  }

  /// Shows an interstitial (e.g. between levels, capped in frequency by
  /// the caller so it never feels intrusive — good UX is part of the
  /// premium feel Gilbert is going for).
  Future<void> showInterstitial() async {
    final ad = _interstitialAd;
    if (ad == null) return;
    await ad.show();
    _interstitialAd = null;
    _loadInterstitial();
  }
}
