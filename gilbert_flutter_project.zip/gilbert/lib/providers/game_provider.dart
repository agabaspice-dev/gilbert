import 'package:flutter/foundation.dart';
import '../core/constants/app_constants.dart';
import '../data/level_generator.dart';
import '../models/level.dart';
import '../services/local_storage_service.dart';
import 'player_provider.dart';

enum WordSubmitResult { none, alreadyFound, notAWord, mainWord, bonusWord }

/// Drives a single active puzzle: the letter circle selection, the
/// crossword board fill state, hints, and scoring for one level at a time.
/// Reused across Classic, Daily, Speed, and Mystery modes — they all
/// operate on a [GilbertLevel] plus mode-specific rules layered by the
/// screen (e.g. Speed Mode adds a countdown on top of this).
class GameProvider extends ChangeNotifier {
  GilbertLevel? _level;
  GilbertLevel get level => _level!;

  final List<int> selectedIndices = [];
  Set<String> foundBoardWords = {};
  Set<String> foundBonusWords = {};

  Map<String, LevelProgress> _allProgress = {};

  bool get isLoaded => _level != null;
  bool get isBoardComplete =>
      _level != null && foundBoardWords.length == _level!.boardWords.length;

  Future<void> loadLevel(GilbertLevel level) async {
    _level = level;
    selectedIndices.clear();
    _allProgress = await LocalStorageService.loadAllProgress();
    final saved = _allProgress[level.id];
    foundBoardWords = Set.from(saved?.foundBoardWords ?? {});
    foundBonusWords = Set.from(saved?.foundBonusWords ?? {});
    notifyListeners();
  }

  // --- Letter selection (swipe-to-connect) ---------------------------------

  void selectLetter(int index) {
    if (selectedIndices.contains(index)) return;
    selectedIndices.add(index);
    notifyListeners();
  }

  /// Called continuously while the user's finger moves; only appends the
  /// index if it's a *new* letter not already part of the current trace,
  /// which is what makes "swipe across letters" feel natural.
  void dragToLetter(int index) => selectLetter(index);

  void clearSelection() {
    selectedIndices.clear();
    notifyListeners();
  }

  String get currentTrace =>
      selectedIndices.map((i) => level.letters[i]).join();

  /// Submits the currently traced word. Returns the outcome so the UI can
  /// animate accordingly (board fill, bonus popup, shake for invalid).
  WordSubmitResult submitCurrentWord(PlayerProvider playerProvider) {
    final word = currentTrace;
    selectedIndices.clear();

    if (word.length < AppConstants.minWordLength) {
      notifyListeners();
      return WordSubmitResult.none;
    }

    final isBoardWord =
        level.boardWords.any((w) => w.word == word);
    final isBonusWord = level.bonusWords.contains(word);

    if (isBoardWord) {
      if (foundBoardWords.contains(word)) {
        notifyListeners();
        return WordSubmitResult.alreadyFound;
      }
      foundBoardWords.add(word);
      final coinsEarned = word.length * AppConstants.coinsPerLetterOfMainWord;
      playerProvider.addCoins(coinsEarned);
      playerProvider.registerWordFound(isBonus: false);
      _persistProgress();
      if (isBoardComplete) {
        playerProvider.addCoins(AppConstants.coinsLevelClearBonus);
      }
      notifyListeners();
      return WordSubmitResult.mainWord;
    }

    if (isBonusWord) {
      if (foundBonusWords.contains(word)) {
        notifyListeners();
        return WordSubmitResult.alreadyFound;
      }
      foundBonusWords.add(word);
      playerProvider.addCoins(AppConstants.coinsPerBonusWord);
      playerProvider.registerWordFound(isBonus: true);
      _persistProgress();
      notifyListeners();
      return WordSubmitResult.bonusWord;
    }

    notifyListeners();
    return WordSubmitResult.notAWord;
  }

  // --- Hints -----------------------------------------------------------

  /// Reveals a single letter of the next unsolved board word for a coin
  /// cost. Returns true if a hint was applied.
  Future<bool> useLetterHint(PlayerProvider playerProvider) async {
    final target = level.boardWords
        .map((w) => w.word)
        .firstWhere((w) => !foundBoardWords.contains(w), orElse: () => '');
    if (target.isEmpty) return false;
    final spent =
        await playerProvider.spendCoins(AppConstants.hintCostReveealLetter);
    if (!spent) return false;
    // In a full implementation this would reveal one letter cell in the UI
    // state; the board widget listens to `revealedHintLetters`.
    revealedHintLetters.putIfAbsent(target, () => 0);
    revealedHintLetters[target] = (revealedHintLetters[target] ?? 0) + 1;
    notifyListeners();
    return true;
  }

  final Map<String, int> revealedHintLetters = {};

  Future<bool> useRevealWordHint(PlayerProvider playerProvider) async {
    final target = level.boardWords
        .map((w) => w.word)
        .firstWhere((w) => !foundBoardWords.contains(w), orElse: () => '');
    if (target.isEmpty) return false;
    final spent =
        await playerProvider.spendCoins(AppConstants.hintCostRevealWord);
    if (!spent) return false;
    foundBoardWords.add(target);
    playerProvider.registerWordFound(isBonus: false);
    _persistProgress();
    notifyListeners();
    return true;
  }

  Future<void> _persistProgress() async {
    final stars = isBoardComplete
        ? (foundBonusWords.isEmpty
            ? 2
            : (foundBonusWords.length >= level.bonusWords.length ? 3 : 2))
        : 0;
    _allProgress[level.id] = LevelProgress(
      levelId: level.id,
      foundBoardWords: foundBoardWords,
      foundBonusWords: foundBonusWords,
      starsEarned: stars,
      completed: isBoardComplete,
    );
    await LocalStorageService.saveProgress(_allProgress);
  }

  int starsForCurrentLevel() {
    if (!isBoardComplete) return 0;
    if (foundBonusWords.length >= level.bonusWords.length &&
        level.bonusWords.isNotEmpty) {
      return 3;
    }
    return foundBonusWords.isEmpty ? 2 : 3;
  }

  static GilbertLevel loadWorldLevel(int world, int levelIdx) =>
      LevelGenerator.generateSingle(world, levelIdx);
}
