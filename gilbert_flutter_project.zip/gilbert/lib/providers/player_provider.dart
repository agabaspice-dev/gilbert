import 'package:flutter/foundation.dart';
import '../core/constants/app_constants.dart';
import '../models/player_profile.dart';
import '../services/local_storage_service.dart';

class PlayerProvider extends ChangeNotifier {
  PlayerProfile? _profile;
  PlayerProfile get profile => _profile ??= PlayerProfile(playerId: 'temp');
  bool get isLoaded => _profile != null;

  List<String> newlyUnlockedAchievements = [];

  Future<void> load() async {
    _profile = await LocalStorageService.loadOrCreateProfile();
    _applyDailyLogin();
    notifyListeners();
  }

  Future<void> _persist() async {
    await LocalStorageService.saveProfile(profile);
  }

  void _applyDailyLogin() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final last = profile.lastLoginDate;

    if (last == null) {
      profile.loginStreak = 1;
    } else {
      final lastDay = DateTime(last.year, last.month, last.day);
      final diff = today.difference(lastDay).inDays;
      if (diff == 0) {
        return; // already logged in today
      } else if (diff == 1) {
        profile.loginStreak += 1;
      } else {
        profile.loginStreak = 1; // streak broken
      }
    }
    profile.lastLoginDate = today;
    final streakDay =
        profile.loginStreak.clamp(1, AppConstants.maxDailyStreakBonusDay);
    final reward = AppConstants.coinsDailyLoginBase * streakDay;
    profile.coins += reward;
    _checkAchievements();
    _persist();
  }

  Future<void> addCoins(int amount) async {
    profile.coins += amount;
    notifyListeners();
    await _persist();
  }

  Future<bool> spendCoins(int amount) async {
    if (profile.coins < amount) return false;
    profile.coins -= amount;
    notifyListeners();
    await _persist();
    return true;
  }

  Future<void> registerWordFound({required bool isBonus}) async {
    profile.totalWordsFound += 1;
    if (isBonus) profile.totalBonusWordsFound += 1;
    _checkAchievements();
    notifyListeners();
    await _persist();
  }

  Future<void> registerStarsEarned(int stars) async {
    profile.totalStars += stars;
    _checkAchievements();
    notifyListeners();
    await _persist();
  }

  Future<void> registerLevelCompleted(int worldIndex, int levelIndex) async {
    if (worldIndex > profile.currentWorldIndex ||
        (worldIndex == profile.currentWorldIndex &&
            levelIndex >= profile.currentLevelIndex)) {
      final nextLevel = levelIndex + 1;
      if (nextLevel > AppConstants.levelsPerWorld) {
        profile.currentWorldIndex = worldIndex + 1;
        profile.currentLevelIndex = 1;
      } else {
        profile.currentWorldIndex = worldIndex;
        profile.currentLevelIndex = nextLevel;
      }
    }
    _checkAchievements();
    notifyListeners();
    await _persist();
  }

  void _checkAchievements() {
    for (final ach in kAchievements) {
      if (profile.unlockedAchievementIds.contains(ach.id)) continue;
      final value = switch (ach.metric) {
        AchievementMetric.totalWordsFound => profile.totalWordsFound,
        AchievementMetric.totalBonusWordsFound =>
          profile.totalBonusWordsFound,
        AchievementMetric.totalStars => profile.totalStars,
        AchievementMetric.loginStreak => profile.loginStreak,
        AchievementMetric.levelsCompleted =>
          (profile.currentWorldIndex - 1) * AppConstants.levelsPerWorld +
              (profile.currentLevelIndex - 1),
      };
      if (value >= ach.targetValue) {
        profile.unlockedAchievementIds.add(ach.id);
        profile.coins += ach.coinReward;
        newlyUnlockedAchievements.add(ach.id);
      }
    }
  }

  List<String> consumeNewlyUnlocked() {
    final list = List<String>.from(newlyUnlockedAchievements);
    newlyUnlockedAchievements.clear();
    return list;
  }
}
