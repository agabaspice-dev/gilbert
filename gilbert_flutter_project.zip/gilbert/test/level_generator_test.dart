import 'package:flutter_test/flutter_test.dart';
import 'package:gilbert/data/level_generator.dart';

void main() {
  group('LevelGenerator', () {
    test('generates a full world of levels with valid boards', () {
      final levels = LevelGenerator.generateWorld(1);
      expect(levels.length, 15);

      for (final level in levels) {
        expect(level.boardWords, isNotEmpty);
        expect(level.letters.length, greaterThanOrEqualTo(3));

        // Every board word must be spellable from the circle's letters.
        final circleCounts = <String, int>{};
        for (final ch in level.letters) {
          circleCounts[ch] = (circleCounts[ch] ?? 0) + 1;
        }
        for (final word in level.boardWords) {
          final need = <String, int>{};
          for (final ch in word.word.split('')) {
            need[ch] = (need[ch] ?? 0) + 1;
          }
          for (final entry in need.entries) {
            expect(circleCounts[entry.key] ?? 0,
                greaterThanOrEqualTo(entry.value),
                reason: '${word.word} not formable from circle letters');
          }
        }

        // No overlapping cells with conflicting letters.
        final cellMap = <String, String>{};
        for (final word in level.boardWords) {
          final cells = word.cells;
          for (int i = 0; i < cells.length; i++) {
            final key = '${cells[i][0]}_${cells[i][1]}';
            if (cellMap.containsKey(key)) {
              expect(cellMap[key], word.word[i]);
            } else {
              cellMap[key] = word.word[i];
            }
          }
        }
      }
    });

    test('daily challenge is deterministic per date', () {
      final date = DateTime(2026, 8, 4);
      final a = LevelGenerator.generateDaily(date);
      final b = LevelGenerator.generateDaily(date);
      expect(a.letters, b.letters);
      expect(a.boardWords.map((w) => w.word).toList(),
          b.boardWords.map((w) => w.word).toList());
    });

    test('bonus words are formable but not placed on the board', () {
      final level = LevelGenerator.generateSingle(3, 5);
      final boardWordSet = level.boardWords.map((w) => w.word).toSet();
      for (final bonus in level.bonusWords) {
        expect(boardWordSet.contains(bonus), isFalse);
      }
    });
  });
}
