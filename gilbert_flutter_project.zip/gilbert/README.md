# Gilbert — Word Connect Puzzle Game

A premium word-connect crossword puzzle built in Flutter. Swipe letters on a
circular wheel, spell words to fill a crossword-style board, hunt hidden
bonus words, and climb through hundreds of worlds.

## Getting started

This repo is the Flutter **project source** — you'll need the Flutter SDK
installed locally to run it (this build environment has no network/Flutter
toolchain, so it hasn't been `flutter pub get` / compiled here).

```bash
flutter --version        # Flutter 3.22+ / Dart 3.3+ recommended
flutter pub get
flutter run               # run on a connected device/simulator
flutter test               # run the test suite
```

To generate platform folders (this archive ships `lib/`, `test/`, and
`pubspec.yaml` only — the standard Flutter scaffolding for `android/`,
`ios/`, `web/`, etc. is generated locally, since it's toolchain/OS-specific):

```bash
flutter create --org com.yourcompany --project-name gilbert .
```
Run that **once**, from inside this folder, before `flutter pub get` — it
will add `android/`, `ios/`, and other platform directories around the
existing `lib/`.

## Architecture

```
lib/
  core/           theme, colors, app-wide constants
  models/         Level, PlacedWord, PlayerProfile, Achievement
  data/           WordBank (seed dictionary) + LevelGenerator (procedural puzzles)
  providers/      PlayerProvider (profile/coins/streaks), GameProvider (active puzzle session)
  services/       LocalStorageService, AdsService, IapService
  widgets/        LetterCircle, CrosswordGrid, LevelNode, CoinBadge, GilbertLogo, ...
  screens/        Splash, Home (world map), Game, Daily Challenge, Speed Mode,
                  Mystery Words, Profile, Leaderboard, Achievements
```

State management is `provider` (ChangeNotifier) — simple, testable, and
enough for this app's scope. Persistence is `shared_preferences` storing
JSON blobs for the player profile and per-level progress; see
`LocalStorageService` as the single seam to swap in a cloud backend later.

## How puzzles are generated (the "AI puzzle generation" system)

`LevelGenerator` (`lib/data/level_generator.dart`) is a deterministic,
seedable algorithm — not a live network call — that:

1. Picks an anchor word from a difficulty-tiered word list (`WordBank`),
   sized to the level's target difficulty.
2. Builds a scrambled letter set from that word plus a couple of filler
   letters.
3. Finds every other word in the list that's formable from that exact
   letter set.
4. Places as many as will fit into a crossword layout, intersecting on
   shared letters (classic crossword-construction algorithm).
5. Everything formable-but-not-placed becomes a **bonus/mystery word**.

Because it's a pure function of `(worldIndex, levelIndex)` (or `date` for
Daily Challenge), it produces **effectively unlimited, reproducible,
guaranteed-solvable levels offline and instantly** — this is what makes
"thousands of progressively harder levels" and "hundreds of worlds"
tractable without hand-authoring or shipping a huge level database.
`AppConstants.worldsCount` / `levelsPerWorld` control the total (currently
200 worlds × 15 levels = 3,000 levels; raise either constant to scale
further — generation is instant, so there's no content-pipeline cost).

### Layering real generative AI on top

To get themed/seasonal word packs (holidays, movie tie-ins, localized
languages) authored with an LLM:

1. **Offline authoring step** (not in the app): call the Claude API with a
   prompt like *"give me 60 family-friendly English nouns themed around
   `<theme>`, 3-9 letters, one per line"*, then validate each word against
   a real dictionary/wordlist to filter out anything invalid.
2. Save the vetted list as a JSON/text asset (see `assets/words/`).
3. Feed it into `LevelGenerator` exactly like `WordBank.forWorld()` does —
   the generator doesn't care where the word list came from.

Keep AI generation **out of the runtime hot path** on-device: generate
content server-side or during a build step, ship it as static data, and
let the deterministic algorithm turn it into playable levels instantly.
This keeps the app fast, offline-capable, and avoids per-player AI cost.

## Ads & in-app purchases

Both are wired with the `google_mobile_ads` and `in_app_purchase`
packages behind `AdsService` / `IapService` (`lib/services/`), currently
pointed at Google's public **test** ad unit IDs so the app runs safely
out of the box. Before release:

1. Create a real AdMob app + ad units; swap the IDs in `ads_service.dart`.
2. Add your AdMob App ID to `android/app/src/main/AndroidManifest.xml`
   and `ios/Runner/Info.plist` (Flutter's `flutter create` step above
   generates these files; the AdMob plugin's own docs show the exact XML/
   plist keys to add).
3. Create matching product IDs in App Store Connect / Play Console for the
   IDs listed in `iap_service.dart` (`gilbert_coins_small`, `_medium`,
   `_large`, `gilbert_remove_ads`, `gilbert_premium_bundle`).
4. Subscribe to `IapService.instance.purchaseStream` where you want to
   grant entitlements (e.g. in `PlayerProvider`) and call
   `completePurchase` once granted.

## Adding more levels / worlds

Levels aren't hand-authored files — raise `AppConstants.worldsCount` and/or
`levelsPerWorld`, and optionally add richer word lists to `WordBank` for
higher worlds (longer/rarer words = harder levels). No other code changes
needed; the world map, level-lock logic, and generator all read from these
constants.

## Game modes implemented

- **Classic Gilbert Adventure** — `HomeScreen` world map → `GameScreen`.
- **Daily Challenge** — same seeded puzzle for every player each day.
- **Speed Mode** — 90-second rapid-fire word finding across rotating puzzles.
- **Mystery Words** — a curated feed of bonus-word-rich puzzles.

## Known gaps to close before store submission

- Platform folders (`android/`, `ios/`) need generating locally via
  `flutter create` as noted above, then app icons, splash screens, and
  bundle identifiers configured per store guidelines.
- `GilbertLogo` is a vector placeholder brand mark — commission or
  AI-generate final app-icon/store-listing artwork using the same
  gold/indigo palette in `app_colors.dart`.
- Leaderboard uses mock data; wire to a real backend (Firebase, Play
  Games Services, Game Center, or custom API) for real global rankings.
- `WordBank` is a small seed list; swap in a large curated dictionary
  (e.g. an open-source word-frequency list filtered for family-friendly
  content) for production-scale variety.
- Add store-required privacy policy / terms links, and configure
  App Tracking Transparency (iOS) if ads use IDFA.
